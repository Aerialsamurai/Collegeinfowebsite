import mongoose from 'mongoose';

const collegeSchema = new mongoose.Schema({
  // Basic Information
  name: {
    type: String,
    required: [true, 'College name is required'],
    trim: true,
    maxlength: [200, 'College name cannot exceed 200 characters']
  },
  slug: {
    type: String,
    required: [true, 'Slug is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^[a-z0-9-]+$/, 'Slug can only contain lowercase letters, numbers, and hyphens']
  },
  
  // Hero Section
  hero: {
    backgroundImage: {
      type: String,
      required: [true, 'Background image URL is required']
    },
    address: {
      type: String,
      required: [true, 'College address is required'],
      trim: true
    }
  },
  
  // Overview Section
  overview: {
    para1: {
      type: String,
      required: [true, 'Overview paragraph 1 is required'],
      trim: true,
      maxlength: [1800, 'Overview paragraph 1 cannot exceed 1800 characters']
    },
    para2: {
      type: String,
      required: false,
      trim: true,
      maxlength: [1800, 'Overview paragraph 2 cannot exceed 1800 characters']
    },
    para3: {
      type: String,
      required: false,
      trim: true,
      maxlength: [1800, 'Overview paragraph 3 cannot exceed 1800 characters']
    }
  },
  
  // Location Section
  location: {
    address: {
      type: String,
      required: [true, 'Detailed address is required'],
      trim: true
    },
    contactEmail: {
      type: String,
      required: [true, 'Contact email is required'],
      lowercase: true,
      trim: true,
      match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email address']
    },
    contactNumber: {
      type: String,
      required: [true, 'Contact number is required'],
      trim: true,
      match: [/^[\+]?[1-9][\d]{0,15}$/, 'Please enter a valid phone number']
    },
    officialWebsite: {
      type: String,
      required: [true, 'Official website URL is required'],
      trim: true,
      match: [/^https?:\/\/.+/, 'Please enter a valid website URL starting with http:// or https://']
    },
    googleMapsIframe: {
      type: String,
      required: [true, 'Google Maps iframe HTML is required'],
      trim: true
    }
  },
  
  // Fee Structure Section
  feeStructure: {
    type: [{
      category: {
        type: String,
        required: true,
        trim: true
      },
      amount: {
        type: Number,
        required: true,
        min: [0, 'Amount cannot be negative']
      },
      currency: {
        type: String,
        default: 'INR',
        enum: ['INR', 'USD', 'EUR']
      },
      duration: {
        type: String,
        default: 'per year',
        trim: true
      },
      description: {
        type: String,
        trim: true
      }
    }],
    default: []
  },
  
  // Rankings Section
  rankings: {
    type: [{
      rank: {
        type: Number,
        required: true,
        min: [1, 'Rank must be at least 1']
      },
      score: {
        type: Number,
        min: [0, 'Score cannot be negative'],
        max: [100, 'Score cannot exceed 100']
      },
      dataSource: {
        type: String,
        required: true,
        trim: true
      },
      year: {
        type: Number,
        required: true,
        min: [2000, 'Year must be at least 2000'],
        max: [new Date().getFullYear() + 1, 'Year cannot be in the future']
      },
      category: {
        type: String,
        trim: true,
        enum: ['Overall', 'Engineering', 'Management', 'Medical', 'Arts', 'Science', 'Other']
      }
    }],
    default: []
  },
  
  // Admission Section
  admission: {
    description: {
      type: String,
      required: [true, 'Admission description is required'],
      trim: true,
      maxlength: [3000, 'Admission description cannot exceed 3000 characters']
    },
    importantDates: {
      type: [{
        event: {
          type: String,
          required: true,
          trim: true
        },
        date: {
          type: Date,
          required: true
        },
        description: {
          type: String,
          trim: true
        }
      }],
      default: []
    },
    eligibilityCriteria: {
      type: [String],
      default: []
    },
    applicationProcess: {
      type: [String],
      default: []
    }
  },
  
  // Placement Section
  placement: {
    summary: {
      type: String,
      required: [true, 'Placement summary is required'],
      trim: true,
      maxlength: [2000, 'Placement summary cannot exceed 2000 characters']
    },
    packages: {
      type: [{
        category: {
          type: String,
          required: true,
          trim: true,
          enum: ['Highest Package', 'Average Package', 'Median Package', 'Lowest Package']
        },
        amount: {
          type: Number,
          required: true,
          min: [0, 'Package amount cannot be negative']
        },
        currency: {
          type: String,
          default: 'INR',
          enum: ['INR', 'USD', 'EUR']
        },
        duration: {
          type: String,
          default: 'per annum',
          trim: true
        },
        year: {
          type: Number,
          required: true,
          min: [2000, 'Year must be at least 2000'],
          max: [new Date().getFullYear() + 1, 'Year cannot be in the future']
        }
      }],
      default: []
    },
    topRecruiters: {
      type: [String],
      default: []
    },
    placementPercentage: {
      type: Number,
      min: [0, 'Placement percentage cannot be negative'],
      max: [100, 'Placement percentage cannot exceed 100']
    }
  },
  
  // Additional Fields for Scalability
  collegeType: {
    type: String,
    required: true,
    enum: ['Government', 'Private', 'Deemed University', 'Central University', 'State University', 'Autonomous']
  },
  establishedYear: {
    type: Number,
    required: true,
    min: [1800, 'Establishment year must be at least 1800'],
    max: [new Date().getFullYear(), 'Establishment year cannot be in the future']
  },
  accreditation: {
    type: [String],
    default: []
  },
  courses: {
    type: [{
      name: {
        type: String,
        required: true,
        trim: true
      },
      duration: {
        type: String,
        required: true,
        trim: true
      },
      type: {
        type: String,
        enum: ['UG', 'PG', 'Diploma', 'Certificate', 'PhD']
      }
    }],
    default: []
  },
  
  // SEO and Display Fields
  metaTitle: {
    type: String,
    trim: true,
    maxlength: [60, 'Meta title cannot exceed 60 characters']
  },
  metaDescription: {
    type: String,
    trim: true,
    maxlength: [160, 'Meta description cannot exceed 160 characters']
  },
  isActive: {
    type: Boolean,
    default: true
  },
  featured: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Index for better query performance
collegeSchema.index({ slug: 1 });
collegeSchema.index({ name: 1 });
collegeSchema.index({ 'location.contactEmail': 1 });
collegeSchema.index({ isActive: 1, featured: 1 });

// Virtual for full address
collegeSchema.virtual('fullAddress').get(function() {
  return `${this.hero.address}, ${this.location.address}`;
});

// Pre-save middleware to generate slug if not provided
collegeSchema.pre('save', function(next) {
  if (!this.slug) {
    this.slug = this.name
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim('-');
  }
  next();
});

// Static method to find active colleges
collegeSchema.statics.findActive = function() {
  return this.find({ isActive: true });
};

// Instance method to get formatted fee structure
collegeSchema.methods.getFormattedFees = function() {
  return this.feeStructure.map(fee => ({
    ...fee.toObject(),
    formattedAmount: `${fee.currency} ${fee.amount.toLocaleString()} ${fee.duration}`
  }));
};

const College = mongoose.model('College', collegeSchema);

export default College;

